#!/bin/bash

# get all arguments into an array
args=("$@")

# get the last argument
LAST_ARG=${args[${#args[@]}-1]}

if [[ $LAST_ARG == */* ]]
then
  # If the last argument is a path (contains '/'), use it as the full script name
  SCRIPT_PATH="$(readlink -f "$LAST_ARG")"
else
  # When sourced, use BASH_SOURCE instead of $0
  SCRIPT_PATH="$(readlink -f "${BASH_SOURCE[0]}")"
fi

# get the name of the caller script
CALLER_SCRIPT="${BASH_SOURCE[1]}"

# get the full path of the caller script
CALLER_SCRIPT_PATH="$(readlink -f "$CALLER_SCRIPT")"

echo "The full path of the caller script is: $CALLER_SCRIPT_PATH"
echo "This script full path: $SCRIPT_PATH"

# get the secret resolve mode
SECRET_MODE=$1

# set the directory name of the script and go to the ansible playbook folder
export INV_FOLDER="$(dirname "$SCRIPT_PATH")"

case $SECRET_MODE in
  pas)
    # When input parameter is 'pas'
    export EXTRA_PARM=""
    export S="${INV_FOLDER}/f.p"
    
    # Run test with password
    echo "test with password"
    ;;
  key)
    # When input parameter is 'key'
    export EXTRA_PARM=""
    export S="${INV_FOLDER}/f.k"

    # Run test with ssh-key conncetion
    echo "test with ssh key file"
    ;;
  var)
    # When input parameter is 'var'
    # Perform actions based on the location secret
    if [ -n "$RTAP" ] && [ -f "$RTAP" ]; then
      . "$RTAP"
      echo "Sourced $RTAP successfully"
    else
      echo "Warning: RTAP is not set or the file does not exist. Skipping."
    fi
    
    # use extra parameter to run Ansible playbook
    export EXTRA_PARM="--vault-password-file ${INV_FOLDER}/s.file"
    export S="${INV_FOLDER}/f.s"  

    # Run test with Ansible vault variable 
    echo "test with vault file"
    ;;
  *)
    echo "Invalid input parameter. Please use 'pas', 'key', or 'var'."
    ;;
esac

# run connection test
ansible-playbook -i inv_$SECRET_MODE.yml test_connection.yml --extra-vars "server_name=test s=${S}" $EXTRA_PARM 



