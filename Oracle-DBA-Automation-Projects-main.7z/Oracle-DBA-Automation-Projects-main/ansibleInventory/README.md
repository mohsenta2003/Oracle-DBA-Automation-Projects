# Ansible Inventory

For security reasons, we no longer store passwords in plain text within the inventory. To learn how to use Ansible Vault with the master password, please refer to our internal Confluence page. 

